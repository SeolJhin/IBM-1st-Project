package org.myweb.uniplace.domain.support.application;

public class FaqService {

}

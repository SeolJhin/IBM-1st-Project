package org.myweb.uniplace.domain.contract.application;

public class Resident {

}

package org.myweb.uniplace.domain.contract.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.myweb.uniplace.domain.contract.domain.entity.Contract;
import org.myweb.uniplace.domain.file.api.dto.request.FileUploadRequest;
import org.myweb.uniplace.domain.file.api.dto.response.FileResponse;
import org.myweb.uniplace.domain.file.api.dto.response.FileUploadResponse;
import org.myweb.uniplace.domain.file.application.FileService;
import org.myweb.uniplace.domain.file.domain.enums.FileRefType;
import org.myweb.uniplace.domain.property.domain.entity.Building;
import org.myweb.uniplace.domain.property.domain.entity.Room;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContractImageServiceImpl implements ContractImageService {

    private final FileService fileService;
    private final ObjectMapper objectMapper;

    @Value("${contract.template-path:}")
    private String templatePath;

    @Value("${contract.python-path:python3}")
    private String pythonPath;

    @Value("${contract.script-path:}")
    private String scriptPath;

    @Value("${contract.temp-dir:/tmp/contract_images}")
    private String tempDir;

    @Value("${file.upload-path:C:/uniplace/uploads}")
    private String uploadBasePath;

    @Override
    public Integer generateAndSave(Contract contract) {
        if (!isConfigured()) {
            log.warn("[ContractImage] 설정 미완료 - template={}, script={}", templatePath, scriptPath);
            return null;
        }

        Path outputPath = null;
        try {
            // 1. 임시 출력 경로
            Path tempDirPath = Paths.get(tempDir);
            Files.createDirectories(tempDirPath);
            String filename = "contract_" + contract.getContractId() + "_"
                    + System.currentTimeMillis() + ".jpg";
            outputPath = tempDirPath.resolve(filename);

            // 2. 데이터 JSON
            String dataJson = objectMapper.writeValueAsString(buildDataMap(contract));

            // 3. 서명 이미지 (옵션)
            String signImgPath = resolveSignImagePath(contract);

            // 4. Python 실행
            if (!runPythonScript(outputPath.toString(), dataJson, signImgPath)) return null;

            // 5. 생성된 파일 → MultipartFile로 변환 → FileService 저장
            byte[] imgBytes = Files.readAllBytes(outputPath);
            String originalName = "contract_" + contract.getContractId() + ".jpg";
            MultipartFile multipart = new ByteArrayMultipartFile(imgBytes, originalName, "image/jpeg");

            FileUploadResponse resp = fileService.uploadFiles(
                    FileUploadRequest.builder()
                            .fileParentType(FileRefType.CONTRACT.dbValue())
                            .fileParentId(contract.getContractId())
                            .files(List.of(multipart))
                            .build()
            );

            List<FileResponse> files = resp != null ? resp.getFiles() : null;
            if (files != null && !files.isEmpty()) {
                int fileId = files.get(0).getFileId();
                log.info("[ContractImage] 계약 #{} 이미지 저장 완료 fileId={}",
                        contract.getContractId(), fileId);
                return fileId;
            }

        } catch (Exception e) {
            log.error("[ContractImage] 계약서 이미지 생성 오류 contractId={}",
                    contract.getContractId(), e);
        } finally {
            if (outputPath != null) {
                try { Files.deleteIfExists(outputPath); } catch (IOException ignored) {}
            }
        }
        return null;
    }

    // ── MockMultipartFile 대신 순수 Java로 MultipartFile 구현 ──────────
    private static class ByteArrayMultipartFile implements MultipartFile {
        private final byte[] content;
        private final String name;
        private final String contentType;

        ByteArrayMultipartFile(byte[] content, String name, String contentType) {
            this.content     = content;
            this.name        = name;
            this.contentType = contentType;
        }

        @Override public String getName()            { return name; }
        @Override public String getOriginalFilename(){ return name; }
        @Override public String getContentType()     { return contentType; }
        @Override public boolean isEmpty()           { return content.length == 0; }
        @Override public long getSize()              { return content.length; }
        @Override public byte[] getBytes()           { return content; }
        @Override public InputStream getInputStream(){ return new ByteArrayInputStream(content); }
        @Override public void transferTo(File dest) throws IOException {
            try (FileOutputStream fos = new FileOutputStream(dest)) {
                fos.write(content);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────

    private boolean isConfigured() {
        return templatePath != null && !templatePath.isBlank()
                && scriptPath != null && !scriptPath.isBlank()
                && Paths.get(templatePath).toFile().exists()
                && Paths.get(scriptPath).toFile().exists();
    }

    private Map<String, String> buildDataMap(Contract contract) {
        Room room = contract.getRoom();
        Building building = room != null ? room.getBuilding() : null;
        Map<String, String> m = new HashMap<>();

        m.put("building_addr", safe(building != null ? building.getBuildingAddr() : ""));
        m.put("room_no",       safe(room != null ? String.valueOf(room.getRoomNo()) : ""));
        m.put("room_size",     room != null && room.getRoomSize() != null
                ? room.getRoomSize().stripTrailingZeros().toPlainString() : "");
        m.put("deposit",    fmtMoney(contract.getDeposit()));
        m.put("rent_price", fmtMoney(contract.getRentPrice()));
        m.put("manage_fee", fmtMoney(contract.getManageFee()));
        m.put("payment_day", contract.getPaymentDay() != null
                ? String.valueOf(contract.getPaymentDay()) : "");

        m.putAll(splitDate("deliver", contract.getContractStart()));
        m.putAll(splitDate("end",     contract.getContractEnd()));

        LocalDate signDate = contract.getSignAt() != null
                ? contract.getSignAt().toLocalDate() : LocalDate.now();
        m.putAll(splitDate("sign", signDate));

        // 임대인 = Building 소유주
        m.put("lessor_nm",   safe(building != null ? building.getBuildingLessorNm() : ""));
        m.put("lessor_tel",  safe(building != null ? building.getBuildingLessorTel() : ""));
        m.put("lessor_addr", safe(building != null ? building.getBuildingLessorAddr() : ""));
        m.put("lessor_rrn",  maskRrn(building != null ? building.getBuildingLessorRrn() : ""));

        // 임차인 = Contract의 lessor_* 컬럼
        m.put("lessee_nm",   safe(contract.getLessorNm()));
        m.put("lessee_tel",  safe(contract.getLessorTel()));
        m.put("lessee_addr", safe(contract.getLessorAddr()));
        m.put("lessee_rrn",  maskRrn(contract.getLessorRrn()));

        return m;
    }

    private Map<String, String> splitDate(String prefix, LocalDate date) {
        Map<String, String> m = new HashMap<>();
        if (date == null) {
            m.put(prefix + "_year", "");
            m.put(prefix + "_month", "");
            m.put(prefix + "_day", "");
            return m;
        }
        m.put(prefix + "_year",  date.format(DateTimeFormatter.ofPattern("yyyy")));
        m.put(prefix + "_month", date.format(DateTimeFormatter.ofPattern("MM")));
        m.put(prefix + "_day",   date.format(DateTimeFormatter.ofPattern("dd")));
        return m;
    }

    private String fmtMoney(BigDecimal v) { return v == null ? "" : String.format("%,.0f", v); }
    private String safe(String s)          { return s != null ? s : ""; }
    private String maskRrn(String rrn) {
        if (rrn == null || rrn.isBlank()) return "";
        return rrn.length() >= 8 ? rrn.substring(0, 8) + "******" : rrn;
    }

    private String resolveSignImagePath(Contract contract) {
        Integer signFileId = contract.getLessorSignFileId();
        if (signFileId == null) return null;
        try {
            FileResponse fr = fileService.getFile(signFileId);
            if (fr == null) return null;
            Path p = Paths.get(uploadBasePath)
                    .resolve(fr.getFilePath())
                    .resolve(fr.getRenameFilename());
            return p.toFile().exists() ? p.toString() : null;
        } catch (Exception e) {
            log.warn("[ContractImage] 서명 이미지 경로 조회 실패: {}", e.getMessage());
            return null;
        }
    }

    private boolean runPythonScript(String outputPath, String dataJson, String signImgPath)
            throws IOException, InterruptedException {

        List<String> cmd = new ArrayList<>(List.of(
                pythonPath, scriptPath,
                "--template", templatePath,
                "--output", outputPath,
                "--data", dataJson
        ));
        if (signImgPath != null) {
            cmd.add("--sign_img");
            cmd.add(signImgPath);
        }

        Process proc = new ProcessBuilder(cmd).redirectErrorStream(false).start();
        String stdout = new String(proc.getInputStream().readAllBytes());
        String stderr = new String(proc.getErrorStream().readAllBytes());
        int exit = proc.waitFor();

        if (!stderr.isBlank()) log.warn("[ContractImage] Python stderr: {}", stderr.trim());
        if (exit != 0) {
            log.error("[ContractImage] Python 실패 exit={} stdout={}", exit, stdout);
            return false;
        }
        return stdout.trim().startsWith("OK:");
    }
}

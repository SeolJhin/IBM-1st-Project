package org.myweb.uniplace.domain.payment.application.gateway.naver.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class NaverApproveResponse {

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @JsonProperty("body")
    private Body body;

    @Getter
    public static class Body {

        @JsonProperty("paymentId")
        private String paymentId;

        @JsonProperty("detail")
        private Detail detail;
    }

    @Getter
    public static class Detail {

        @JsonProperty("paymentId")
        private String paymentId;

        @JsonProperty("merchantPayKey")
        private String merchantPayKey;

        @JsonProperty("admissionState")
        private String admissionState;

        @JsonProperty("totalPayAmount")
        private Integer totalPayAmount;
    }
}

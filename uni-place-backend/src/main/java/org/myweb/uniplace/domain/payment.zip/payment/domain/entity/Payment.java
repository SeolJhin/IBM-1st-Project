package org.myweb.uniplace.domain.payment.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.math.BigDecimal;

@Entity
@Table(name = "payment",
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_payment_merchant_uid", columnNames = "merchant_uid"),
                @UniqueConstraint(name = "uq_payment_idempotency", columnNames = "idempotency_key")
        }
)
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Builder
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Integer paymentId;

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "service_goods_id", nullable = false)
    private Integer serviceGoodsId;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    @Column(name = "amount_total", nullable = false)
    private BigDecimal amountTotal;

    @Column(name = "amount_captured", nullable = false)
    private BigDecimal amountCaptured;

    @Column(name = "amount_refunded", nullable = false)
    private BigDecimal amountRefunded;

    @Column(name = "payment_method_id")
    private Integer paymentMethodId;

    @Column(name = "provider", nullable = false, length = 20)
    private String provider;

    @Column(name = "provider_payment_id")
    private String providerPaymentId;

    @Column(name = "provider_tid")
    private String providerTid;

    @Column(name = "merchant_uid", nullable = false)
    private String merchantUid;

    @Column(name = "idempotency_key")
    private String idempotencyKey;

    @Column(name = "payment_status", nullable = false)
    private String paymentStatus;

    @Column(name = "fail_code")
    private String failCode;

    @Column(name = "fail_message")
    private String failMessage;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "paid_at")
    private LocalDateTime paidAt;

    @Column(name = "canceled_at")
    private LocalDateTime canceledAt;

    public void markPaid(LocalDateTime paidAt) {
        this.paymentStatus = "paid";
        this.paidAt = paidAt;
    }

    public void markCanceled(LocalDateTime canceledAt) {
        this.paymentStatus = "cancelled";
        this.canceledAt = canceledAt;
    }

    public void markFailed(String code, String message) {
        this.paymentStatus = "failed";
        this.failCode = code;
        this.failMessage = message;
    }
}
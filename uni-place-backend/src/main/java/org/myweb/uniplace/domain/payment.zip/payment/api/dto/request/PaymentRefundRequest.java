package org.myweb.uniplace.domain.payment.api.dto.request;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class PaymentRefundRequest {

    private Integer paymentId;
    private BigDecimal refundAmount;
    private String reason;
}
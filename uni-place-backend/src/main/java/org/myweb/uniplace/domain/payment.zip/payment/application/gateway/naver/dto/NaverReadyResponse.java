package org.myweb.uniplace.domain.payment.application.gateway.naver.dto;

public class NaverReadyResponse {

}

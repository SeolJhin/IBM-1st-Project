package org.myweb.uniplace.domain.payment.application;

public class PaymentService {

}

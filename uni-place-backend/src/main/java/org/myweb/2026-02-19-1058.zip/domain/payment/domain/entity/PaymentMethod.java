package org.myweb.uniplace.domain.payment.domain.entity;

public class PaymentMethod {

}

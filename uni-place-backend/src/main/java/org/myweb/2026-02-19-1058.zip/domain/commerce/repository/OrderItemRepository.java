package org.myweb.uniplace.domain.commerce.repository;

public class OrderItemRepository {

}

package org.myweb.uniplace.global.security;

import lombok.RequiredArgsConstructor;
import org.myweb.uniplace.domain.user.domain.User;
import org.myweb.uniplace.domain.user.domain.enums.UserStatus;
import org.myweb.uniplace.global.exception.CustomException;
import org.myweb.uniplace.global.exception.ErrorCode;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserStatusGuard {

    public void checkWritable(User user) {

        if (user.getUserSt() == UserStatus.banned) {
            throw new CustomException(ErrorCode.USER_BANNED);
        }

        if (user.getUserSt() == UserStatus.inactive) {
            throw new CustomException(ErrorCode.USER_INACTIVE);
        }
    }
}
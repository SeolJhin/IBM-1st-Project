const { createProxyMiddleware } = require('http-proxy-middleware');
module.exports = function (app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:8080',
      changeOrigin: true,
      ws: true,
      pathRewrite: {
        '^/api': '',
      },
    })
  );
  app.use(
    '/ai/payment/order-form/download',
    createProxyMiddleware({
      target: 'http://localhost:8080',
      changeOrigin: true,
    })
  );

  const { createProxyMiddleware } = require('http-proxy-middleware');
  const proxyTarget =
    process.env.FRONTEND_PROXY_TARGET || 'http://localhost:8080';

  module.exports = function (app) {
    app.use(
<<<<<<< HEAD
      createProxyMiddleware({
        target: proxyTarget,
        changeOrigin: true,
        ws: true,
        pathFilter: ['/api'],
      })
=======
        createProxyMiddleware("/api", {
            target: proxyTarget,
            changeOrigin: true,
            ws: true,
            logLevel: "warn",
        })
>>>>>>> 229a363d06dc6fc12f9e67665a19b5687e8e9611
    );
  };
};

// src/features/chat/hooks/useChat.js
import { useState, useCallback, useRef, useEffect } from 'react';
import {
  loadHistory,
  saveHistory,
  clearHistory,
  sendToGemini,
  sendToBackend,
} from '../api/chatApi';
import { tokenStore } from '../../../app/http/tokenStore';

var SYSTEM_PROMPT =
  '당신은 UNI PLACE의 AI 어시스턴트입니다.\n' +
  'UNI PLACE는 Living as a Service를 제공하는 주거 플랫폼으로,\n' +
  '계약 관리, 공용 공간 예약, 커뮤니티, 결제, 룸서비스 등을 지원합니다.\n\n' +
  '다음 규칙을 따라주세요:\n' +
  '- 항상 친절하고 전문적으로 응답하세요.\n' +
  '- 한국어로 응답하세요.\n' +
  '- UNI PLACE 서비스와 관련된 질문에 우선적으로 답변하세요.\n' +
  '- 모르는 내용은 솔직하게 모른다고 말하고, 고객센터 연락을 안내하세요.\n' +
  '- 개인정보나 민감한 데이터는 절대 요청하지 마세요.';

// FastAPI 직접 호출 (STT/TTS는 파일 전송이므로 Spring 우회)
var FASTAPI_BASE = 'http://localhost:8000';
var VOICE_STT_URL = FASTAPI_BASE + '/api/v1/ai/voice/stt';
var VOICE_TTS_URL = FASTAPI_BASE + '/api/v1/ai/voice/tts';

// JWT 헤더 포함 fetch
function authFetch(url, options) {
  var opts = options || {};
  var token = tokenStore.getAccess();
  var headers = Object.assign({}, opts.headers || {});
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
  }
  return fetch(url, Object.assign({}, opts, { headers: headers }));
}

export function useChat(params) {
  var user = params.user;
  var geminiApiKey = params.geminiApiKey;
  var useBackend = params.useBackend || false;
  var autoTTS = params.autoTTS || false;

  var userId = null;
  if (user) {
    userId = user.userId || user.id || null;
  }
  var userRole = 'guest';
  if (user) {
    userRole = user.userRole || user.role || 'guest';
  }

  var historyInit = loadHistory(userId, userRole);
  var messagesState = useState(historyInit);
  var messages = messagesState[0];
  var setMessages = messagesState[1];

  var inputState = useState('');
  var input = inputState[0];
  var setInput = inputState[1];

  var loadingState = useState(false);
  var loading = loadingState[0];
  var setLoading = loadingState[1];

  var errorState = useState(null);
  var error = errorState[0];
  var setError = errorState[1];

  var recordingState = useState(false);
  var isRecording = recordingState[0];
  var setIsRecording = recordingState[1];

  var speakingState = useState(false);
  var isSpeaking = speakingState[0];
  var setIsSpeaking = speakingState[1];

  var bottomRef = useRef(null);
  var mediaRecRef = useRef(null);
  var audioChunks = useRef([]);
  var audioRef = useRef(null);

  useEffect(
    function () {
      saveHistory(userId, userRole, messages);
    },
    [messages, userId, userRole]
  );

  useEffect(
    function () {
      if (bottomRef.current) {
        bottomRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    },
    [messages, loading]
  );

  // ── 텍스트 전송 ──────────────────────────────────────────
  var sendMessage = useCallback(
    function (text) {
      var trimmed = (text != null ? text : input).trim();
      if (!trimmed || loading) return Promise.resolve();

      setInput('');
      setError(null);

      var userMsg = { role: 'user', content: trimmed, ts: Date.now() };
      var nextMessages = messages.concat([userMsg]);
      setMessages(nextMessages);
      setLoading(true);

      var promise;
      if (useBackend) {
        promise = sendToBackend(trimmed, userId, userRole);
      } else {
        if (!geminiApiKey) {
          setError('API 키가 설정되지 않았습니다.');
          setLoading(false);
          return Promise.resolve();
        }
        var history = nextMessages.slice(-20).slice(0, -1);
        promise = sendToGemini(geminiApiKey, SYSTEM_PROMPT, history, trimmed);
      }

      return promise
        .then(function (answer) {
          var assistantMsg = {
            role: 'assistant',
            content: answer,
            ts: Date.now(),
          };
          setMessages(function (prev) {
            return prev.concat([assistantMsg]);
          });
          if (autoTTS) {
            speakText(answer);
          }
        })
        .catch(function (e) {
          var msg =
            e && e.message
              ? e.message
              : '오류가 발생했습니다. 잠시 후 다시 시도해 주세요.';
          setError(msg);
        })
        .finally(function () {
          setLoading(false);
        });
    },
    [
      input,
      loading,
      messages,
      geminiApiKey,
      useBackend,
      userId,
      userRole,
      autoTTS,
    ]
  );

  // ── 마이크 녹음 시작 ─────────────────────────────────────
  var startRecording = useCallback(
    function () {
      if (isRecording) return;
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then(function (stream) {
          var mimeType = MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm'
            : 'audio/wav';
          var recorder = new MediaRecorder(stream, { mimeType: mimeType });
          audioChunks.current = [];

          recorder.ondataavailable = function (e) {
            audioChunks.current.push(e.data);
          };
          recorder.onstop = function () {
            stream.getTracks().forEach(function (t) {
              t.stop();
            });
            var blob = new Blob(audioChunks.current, { type: mimeType });
            transcribeAudio(blob, mimeType);
          };

          recorder.start();
          mediaRecRef.current = recorder;
          setIsRecording(true);
        })
        .catch(function (e) {
          setError('마이크 접근 실패: ' + e.message);
        });
    },
    [isRecording]
  );

  // ── 마이크 녹음 중지 ─────────────────────────────────────
  var stopRecording = useCallback(
    function () {
      if (!isRecording || !mediaRecRef.current) return;
      mediaRecRef.current.stop();
      mediaRecRef.current = null;
      setIsRecording(false);
    },
    [isRecording]
  );

  // ── STT: 오디오 → 텍스트 → 자동 전송 ───────────────────
  function transcribeAudio(audioBlob, mimeType) {
    setLoading(true);
    setError(null);
    var ext = mimeType.indexOf('webm') >= 0 ? 'webm' : 'wav';
    var formData = new FormData();
    formData.append('file', audioBlob, 'recording.' + ext);

    authFetch(VOICE_STT_URL, { method: 'POST', body: formData })
      .then(function (res) {
        if (!res.ok) {
          throw new Error('STT 실패 (' + res.status + ')');
        }
        return res.json();
      })
      .then(function (data) {
        var transcribed = data && data.text ? data.text.trim() : '';
        if (transcribed) {
          sendMessage(transcribed);
        } else {
          setError('음성을 인식하지 못했습니다.');
          setLoading(false);
        }
      })
      .catch(function (e) {
        setError('STT 오류: ' + e.message);
        setLoading(false);
      });
  }

  // ── TTS: 텍스트 → 음성 재생 ─────────────────────────────
  var speakText = useCallback(function (text) {
    if (!text || !text.trim()) return;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsSpeaking(true);

    var formData = new FormData();
    formData.append('text', text);
    formData.append('lang', 'ko');
    formData.append('speed', '1.0');
    formData.append('output_format', 'wav');

    authFetch(VOICE_TTS_URL, { method: 'POST', body: formData })
      .then(function (res) {
        if (!res.ok) {
          throw new Error('TTS 실패 (' + res.status + ')');
        }
        return res.arrayBuffer();
      })
      .then(function (buffer) {
        var blob = new Blob([buffer], { type: 'audio/wav' });
        var url = URL.createObjectURL(blob);
        var audio = new Audio(url);
        audioRef.current = audio;
        audio.onended = function () {
          URL.revokeObjectURL(url);
          audioRef.current = null;
          setIsSpeaking(false);
        };
        audio.onerror = function () {
          URL.revokeObjectURL(url);
          audioRef.current = null;
          setIsSpeaking(false);
        };
        audio.play();
      })
      .catch(function (e) {
        setIsSpeaking(false);
        console.warn('TTS 오류:', e.message);
      });
  }, []);

  var stopSpeaking = useCallback(function () {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsSpeaking(false);
  }, []);

  var clear = useCallback(
    function () {
      clearHistory(userId);
      setMessages([]);
      setError(null);
      stopSpeaking();
    },
    [userId, stopSpeaking]
  );

  return {
    messages: messages,
    input: input,
    setInput: setInput,
    loading: loading,
    error: error,
    sendMessage: sendMessage,
    clear: clear,
    bottomRef: bottomRef,
    userRole: userRole,
    isRecording: isRecording,
    isSpeaking: isSpeaking,
    startRecording: startRecording,
    stopRecording: stopRecording,
    speakText: speakText,
    stopSpeaking: stopSpeaking,
  };
}

/**
 * ChatBot.jsx — UNI PLACE 플로팅 챗봇 컴포넌트
 * 위치: src/features/chat/components/ChatBot.jsx
 *
 * 기능:
 *  - 플로팅 버튼(FAB) → 채팅 패널 열기/닫기
 *  - 텍스트 입력 + 전송
 *  - 🎤 마이크 버튼 → Whisper STT → 자동 전송
 *  - 🔊 스피커 버튼 → MeloTTS 음성 재생
 *  - 빠른 질문 칩
 *  - 대화기록 보존기간 배너 (역할별)
 */
import React, { useState } from "react";
import { useChat } from "../hooks/useChat";
import styles from "./ChatBot.module.css";

const QUICK_QUESTIONS = [
  "방 예약 방법이 궁금해요",
  "공용 공간 이용 시간이 어떻게 되나요?",
  "계약 갱신은 어떻게 하나요?",
  "룸서비스 신청하고 싶어요",
];

export default function ChatBot({ user, geminiApiKey, useBackend = false }) {
  const [open, setOpen] = useState(false);
  const [autoTTS, setAutoTTS] = useState(false);

  const {
    messages,
    input, setInput,
    loading,
    error,
    sendMessage,
    clear,
    bottomRef,
    retentionLabel,
    isRecording,
    isSpeaking,
    startRecording,
    stopRecording,
    speakText,
    stopSpeaking,
  } = useChat({ user, geminiApiKey, useBackend, autoTTS });

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleMicClick = () => {
    if (isRecording) stopRecording();
    else startRecording();
  };

  return (
    <>
      {/* ── 플로팅 버튼 ── */}
      <button
        className={styles.fab}
        onClick={() => setOpen(o => !o)}
        aria-label="AI 챗봇 열기"
      >
        {open ? "✕" : "💬"}
      </button>

      {/* ── 채팅 패널 ── */}
      {open && (
        <div className={styles.panel}>
          {/* 헤더 */}
          <div className={styles.header}>
            <span className={styles.headerTitle}>🏠 UNI PLACE AI</span>
            <div className={styles.headerActions}>
              {/* TTS 자동 재생 토글 */}
              <button
                className={`${styles.iconBtn} ${autoTTS ? styles.iconBtnActive : ""}`}
                onClick={() => setAutoTTS(v => !v)}
                title={autoTTS ? "음성 자동 재생 켜짐" : "음성 자동 재생 꺼짐"}
              >
                🔊
              </button>
              <button className={styles.clearBtn} onClick={clear} title="대화 초기화">
                🗑
              </button>
              <button className={styles.closeBtn} onClick={() => setOpen(false)}>
                ✕
              </button>
            </div>
          </div>

          {/* 보존기간 배너 */}
          <div className={styles.retention}>{retentionLabel}</div>

          {/* 메시지 영역 */}
          <div className={styles.messages}>
            {messages.length === 0 && (
              <div className={styles.empty}>
                <p>안녕하세요! 무엇을 도와드릴까요?</p>
                <div className={styles.quickChips}>
                  {QUICK_QUESTIONS.map((q) => (
                    <button
                      key={q}
                      className={styles.chip}
                      onClick={() => sendMessage(q)}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg, i) => (
              <div
                key={i}
                className={`${styles.message} ${
                  msg.role === "user" ? styles.userMsg : styles.aiMsg
                }`}
              >
                <span className={styles.msgContent}>{msg.content}</span>
                {/* AI 메시지에 TTS 버튼 */}
                {msg.role === "assistant" && (
                  <button
                    className={styles.ttsBtn}
                    onClick={() =>
                      isSpeaking ? stopSpeaking() : speakText(msg.content)
                    }
                    title="음성으로 듣기"
                  >
                    {isSpeaking ? "⏹" : "▶"}
                  </button>
                )}
              </div>
            ))}

            {loading && (
              <div className={`${styles.message} ${styles.aiMsg}`}>
                <span className={styles.typing}>
                  <span />
                  <span />
                  <span />
                </span>
              </div>
            )}

            {error && (
              <div className={styles.errorMsg}>⚠ {error}</div>
            )}

            <div ref={bottomRef} />
          </div>

          {/* 입력 영역 */}
          <div className={styles.inputArea}>
            {/* 마이크 버튼 */}
            <button
              className={`${styles.micBtn} ${isRecording ? styles.micRecording : ""}`}
              onClick={handleMicClick}
              title={isRecording ? "녹음 중지" : "음성 입력"}
              disabled={loading}
            >
              {isRecording ? "⏹" : "🎤"}
            </button>

            <textarea
              className={styles.input}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="메시지를 입력하세요..."
              rows={1}
              disabled={loading || isRecording}
            />
            <button
              className={styles.sendBtn}
              onClick={() => sendMessage()}
              disabled={!input.trim() || loading}
            >
              ➤
            </button>
          </div>

          {/* 녹음 중 표시 */}
          {isRecording && (
            <div className={styles.recordingBanner}>
              🔴 녹음 중... (버튼을 눌러 중지)
            </div>
          )}
        </div>
      )}
    </>
  );
}

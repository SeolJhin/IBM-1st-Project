import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../../app/layouts/components/Header';
import Footer from '../../../app/layouts/components/Footer';
import { communityApi } from '../api/communityApi';
import { adminApi } from '../../admin/api/adminApi';
import { useAuth } from '../../user/hooks/useAuth';
import UserStatusModal from '../../user/components/UserStatusModal';
import styles from './CommunityHome.module.css';
import { reviewApi } from '../../review/api/reviewApi';
import ReviewModal from '../../review/components/ReviewModal';
import { fileApi, toApiImageUrl } from '../../file/api/fileApi';

function normalizeTab(value) {
  const k = String(value ?? '').toUpperCase();
  if (k === 'FREE') return 'FREE';
  if (k === 'QUESTION') return 'QUESTION';
  if (k === 'REVIEW') return 'REVIEW';
  return 'ALL';
}

const COMMUNITY_IMAGES = {
  ALL: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1400&q=80',
  FREE: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1400&q=80',
  QUESTION:
    'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=1400&q=80',
  REVIEW:
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1400&q=80',
};
const TABS = [
  { key: 'ALL', label: '전체' },
  { key: 'FREE', label: '자유' },
  { key: 'QUESTION', label: '질문' },
  { key: 'REVIEW', label: '후기' },
];

const TITLE_MAP = {
  ALL: '커뮤니티',
  FREE: '자유 게시판',
  QUESTION: '질문 게시판',
  REVIEW: '후기 게시판',
};

const SUBTITLE_MAP = {
  ALL: '자유롭게 소통하고 정보를 나눠보세요.',
  FREE: '자유롭게 이야기를 나눠보세요.',
  QUESTION: '궁금한 점을 질문하고 답변을 받아보세요.',
  REVIEW: '입주 후기를 공유하고 참고해보세요.',
};

const EYEBROW_MAP = {
  ALL: 'COMMUNITY',
  FREE: 'FREE BOARD',
  QUESTION: 'Q & A',
  REVIEW: 'REVIEW',
};

function formatDate(value) {
  if (!value) return '-';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString('ko-KR');
}

function typeLabel(value) {
  const k = String(value ?? '').toUpperCase();
  if (k === 'FREE' || k === 'BOARD_FREE') return '자유';
  if (k === 'QUESTION' || k === 'BOARD_QUESTION') return '질문';
  if (k === 'REVIEW' || k === 'BOARD_REVIEW') return '후기';
  if (k === 'NOTICE' || k === 'BOARD_NOTICE') return '공지';
  return '일반';
}

function typeKey(value) {
  const k = String(value ?? '').toUpperCase();
  if (k === 'FREE' || k === 'BOARD_FREE') return 'free';
  if (k === 'QUESTION' || k === 'BOARD_QUESTION') return 'question';
  if (k === 'REVIEW' || k === 'BOARD_REVIEW') return 'review';
  if (k === 'NOTICE' || k === 'BOARD_NOTICE') return 'notice';
  return 'default';
}

// ── 리치텍스트 에디터 ───────────────────────────────────────────
function RichEditor({ onChange, disabled }) {
  const ref = useRef(null);
  const FONT_SIZES = [
    '12px',
    '14px',
    '16px',
    '18px',
    '20px',
    '24px',
    '28px',
    '32px',
  ];
  const COLORS = [
    '#111827',
    '#ef4444',
    '#f97316',
    '#eab308',
    '#22c55e',
    '#3b82f6',
    '#8b5cf6',
    '#ec4899',
    '#64748b',
  ];

  const exec = (cmd, val) => {
    ref.current?.focus();
    document.execCommand(cmd, false, val ?? null);
  };

  const applySize = (e) => {
    const size = e.target.value;
    exec('fontSize', '7');
    ref.current?.querySelectorAll('font[size="7"]').forEach((s) => {
      s.removeAttribute('size');
      s.style.fontSize = size;
    });
    onChange(ref.current?.innerHTML ?? '');
  };

  const applyColor = (c) => {
    exec('foreColor', c);
    onChange(ref.current?.innerHTML ?? '');
  };

  return (
    <div className={styles.richEditor}>
      <div className={styles.toolbar}>
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('bold');
          }}
        >
          <b>B</b>
        </button>
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('italic');
          }}
        >
          <i>I</i>
        </button>
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('underline');
          }}
        >
          <u>U</u>
        </button>
        <span className={styles.toolDivider} />
        <select
          className={styles.toolSelect}
          defaultValue="16px"
          onChange={applySize}
          onMouseDown={(e) => e.stopPropagation()}
        >
          {FONT_SIZES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <div className={styles.colorPicker}>
          <div className={styles.colorSwatchWrap} title="글자색">
            <span>A</span>
            <div className={styles.colorDropdown}>
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={styles.colorBtn}
                  style={{ background: c }}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    applyColor(c);
                  }}
                />
              ))}
            </div>
          </div>
        </div>
        <span className={styles.toolDivider} />
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('justifyLeft');
          }}
        >
          ≡
        </button>
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('justifyCenter');
          }}
        >
          ☰
        </button>
        <button
          type="button"
          className={styles.toolBtn}
          onMouseDown={(e) => {
            e.preventDefault();
            exec('justifyRight');
          }}
        >
          ≡
        </button>
      </div>
      <div
        ref={ref}
        className={styles.editorArea}
        contentEditable={!disabled}
        onInput={() => onChange(ref.current?.innerHTML ?? '')}
        suppressContentEditableWarning
        data-placeholder="내용을 입력하세요"
      />
    </div>
  );
}

// ── 이미지 삽입 버튼 ────────────────────────────────────────────
function InlineImageBtn({ onInsert, disabled }) {
  const inputRef = useRef(null);
  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    // base64(readAsDataURL) 대신 blob URL 사용 — DB에 base64가 저장되는 버그 방지
    const blobUrl = URL.createObjectURL(file);
    onInsert(blobUrl, file);
    e.target.value = '';
  };
  return (
    <>
      <button
        type="button"
        className={styles.imgInsertBtn}
        onClick={() => inputRef.current?.click()}
        disabled={disabled}
      >
        🖼 이미지 삽입
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        onChange={handleFile}
      />
    </>
  );
}

// ── 메인 컴포넌트 ───────────────────────────────────────────────
export default function CommunityHome() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState(() =>
    normalizeTab(searchParams.get('tab'))
  );

  /* ── 히어로 이미지 fade 전환 (Support 방식) ── */
  const [heroImg, setHeroImg] = useState(
    () =>
      COMMUNITY_IMAGES[normalizeTab(searchParams.get('tab'))] ||
      COMMUNITY_IMAGES.ALL
  );
  const [heroFade, setHeroFade] = useState(true);
  const prevTab = useRef(activeTab);

  // 헤더 드롭다운 등 외부 navigate로 URL이 바뀔 때 activeTab을 동기화
  // (searchParams는 React Router가 반응형으로 업데이트 해줌)
  useEffect(() => {
    const tabFromUrl = normalizeTab(searchParams.get('tab'));
    if (tabFromUrl !== activeTab) {
      setActiveTab(tabFromUrl);
      setPage(1);
      setSearchKeyword('');
      setSearchType('title');
      setActiveSearch({ type: '', keyword: '' });
      setShowWriter(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  /* 탭 변경 시 히어로 이미지 fade 전환 */
  useEffect(() => {
    if (activeTab === prevTab.current) return;
    prevTab.current = activeTab;
    setHeroFade(false);
    const t = setTimeout(() => {
      setHeroImg(COMMUNITY_IMAGES[activeTab] || COMMUNITY_IMAGES.ALL);
      setHeroFade(true);
    }, 320);
    return () => clearTimeout(t);
  }, [activeTab]);
  const [reviewModal, setReviewModal] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const [showWriter, setShowWriter] = useState(false);
  const [writeTitle, setWriteTitle] = useState('');
  const [writeContent, setWriteContent] = useState('');
  const [pendingImages, setPendingImages] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [anonymous, setAnonymous] = useState(false);

  const editorContainerRef = useRef(null);

  const isLoggedIn = !!user;
  const userRole = String(user?.userRole ?? '').toLowerCase();
  const isAdmin = userRole === 'admin';
  const isTenant = userRole === 'tenant';
  const isBanned = String(user?.userSt ?? '').toLowerCase() === 'banned';

  const [userStatusModalId, setUserStatusModalId] = useState(null);

  const [searchType, setSearchType] = useState(
    () => searchParams.get('searchType') || 'title'
  );
  const [searchKeyword, setSearchKeyword] = useState(
    () => searchParams.get('keyword') || ''
  );
  const [activeSearch, setActiveSearch] = useState(() => {
    const kw = searchParams.get('keyword') || '';
    const st = searchParams.get('searchType') || 'title';
    return kw ? { type: st, keyword: kw } : { type: '', keyword: '' };
  });

  useEffect(() => {
    const onPop = () => {
      const params = new URLSearchParams(window.location.search);
      const nextTab = normalizeTab(params.get('tab'));
      const kw = params.get('keyword') || '';
      const st = params.get('searchType') || 'title';
      setActiveTab(nextTab);
      setSearchType(st);
      setSearchKeyword(kw);
      setActiveSearch(
        kw ? { type: st, keyword: kw } : { type: '', keyword: '' }
      );
      setPage(1);
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const effectiveCode = (() => {
    if (activeTab === 'FREE') return 'FREE';
    if (activeTab === 'QUESTION') return 'QUESTION';
    if (activeTab === 'NOTICE') return 'NOTICE';
    return 'FREE';
  })();

  const canOpenWriter = (() => {
    if (!isLoggedIn) return false;
    if (activeTab === 'REVIEW') return false;
    if (activeTab === 'NOTICE') return isAdmin;
    if (activeTab === 'QUESTION') return isAdmin || isTenant;
    return true;
  })();

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      let data;
      if (activeTab === 'REVIEW') {
        data = await reviewApi.getAll({ page: page - 1, size: 10 });
        const content = Array.isArray(data?.content) ? data.content : [];
        const sortedReview = [...content].sort((a, b) => {
          const at = a?.createdAt ?? '';
          const bt = b?.createdAt ?? '';
          if (bt > at) return 1;
          if (bt < at) return -1;
          return (b?.reviewId ?? 0) - (a?.reviewId ?? 0);
        });
        setItems(sortedReview);
        setTotalPages(Math.max(1, Number(data?.totalPages ?? 1)));
        return;
      }
      if (activeSearch.keyword && activeSearch.keyword.trim()) {
        data = await communityApi.searchBoards({
          page,
          size: 10,
          boardType: activeTab,
          searchType: activeSearch.type || 'title',
          keyword: activeSearch.keyword.trim(),
        });
      } else {
        data = await communityApi.getBoards({
          page,
          size: 10,
          boardType: activeTab,
        });
      }
      const content = Array.isArray(data?.content)
        ? data.content
        : Array.isArray(data)
          ? data
          : [];
      const sorted = [...content].sort((a, b) => {
        const aNotice = a?.importance === 'Y' ? 0 : 1;
        const bNotice = b?.importance === 'Y' ? 0 : 1;
        if (aNotice !== bNotice) return aNotice - bNotice;
        const at = a?.createdAt ?? '';
        const bt = b?.createdAt ?? '';
        if (bt > at) return 1;
        if (bt < at) return -1;
        return (b?.boardId ?? 0) - (a?.boardId ?? 0);
      });
      setItems(sorted);
      setTotalPages(Math.max(1, Number(data?.totalPages ?? 1)));
    } catch (e) {
      setItems([]);
      setTotalPages(1);
      setError(e?.message || '게시글을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }, [activeTab, page, isAdmin, activeSearch]);

  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    if (!canOpenWriter) setShowWriter(false);
  }, [canOpenWriter]);

  const handleTabChange = (tabKey) => {
    setActiveTab(tabKey);
    setShowWriter(false);
    setPage(1);
    setSearchKeyword('');
    setSearchType('title');
    setActiveSearch({ type: '', keyword: '' });
    const next = new URLSearchParams();
    if (tabKey !== 'ALL') next.set('tab', tabKey);
    setSearchParams(next, { replace: true });
  };

  const handleSearch = () => {
    setPage(1);
    setActiveSearch({ type: searchType, keyword: searchKeyword });
    const next = new URLSearchParams();
    if (activeTab !== 'ALL') next.set('tab', activeTab);
    if (searchKeyword.trim()) {
      next.set('searchType', searchType);
      next.set('keyword', searchKeyword.trim());
    }
    setSearchParams(next, { replace: true });
  };

  const handleSearchReset = () => {
    setSearchKeyword('');
    setActiveSearch({ type: '', keyword: '' });
    setPage(1);
    const next = new URLSearchParams();
    if (activeTab !== 'ALL') next.set('tab', activeTab);
    setSearchParams(next, { replace: true });
  };

  const handleAdminDeleteBoard = async (boardId, e) => {
    e.stopPropagation();
    if (!window.confirm('관리자 권한으로 이 게시글을 삭제할까요?')) return;
    try {
      await adminApi.adminDeleteBoard(boardId);
      await load();
    } catch (err) {
      window.alert(err?.message || '삭제 실패');
    }
  };

  const pageButtons = useMemo(() => {
    const from = Math.max(1, page - 2);
    const to = Math.min(totalPages, page + 2);
    const nums = [];
    for (let p = from; p <= to; p++) nums.push(p);
    return nums;
  }, [page, totalPages]);

  const handleInsertImage = (blobUrl, file) => {
    const editorEl =
      editorContainerRef.current?.querySelector('[contenteditable]');
    if (editorEl) {
      editorEl.focus();
      const img = document.createElement('img');
      img.src = blobUrl;
      img.setAttribute('data-pending-img', '1'); // 저장 시 서버 URL로 교체할 마커
      img.style.cssText =
        'max-width:100%;border-radius:8px;margin:8px 0;display:block;';
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        range.insertNode(img);
        range.setStartAfter(img);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      } else {
        editorEl.appendChild(img);
      }
      setWriteContent(editorEl.innerHTML);
    }
    setPendingImages((prev) => [...prev, { blobUrl, file }]);
  };

  const submitPost = async () => {
    if (!isLoggedIn) {
      setError('로그인이 필요합니다.');
      return;
    }
    if (isBanned) {
      setError('정지(banned) 상태의 계정은 커뮤니티 글을 작성할 수 없습니다.');
      return;
    }
    const title = writeTitle.trim();
    const contentText = (writeContent ?? '').replace(/<[^>]*>/g, '').trim();
    if (!title) {
      setError('제목을 입력해주세요.');
      return;
    }
    if (!contentText) {
      setError('내용을 입력해주세요.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      // 1. 게시글 먼저 생성 (boardCtnt는 blob URL 포함 상태로 임시 저장)
      const created = await communityApi.createBoard({
        boardTitle: title,
        boardCtnt: writeContent,
        code: effectiveCode,
        anonymity: anonymous ? 'Y' : 'N',
      });

      // 2. 이미지가 있으면 업로드 후 blob URL → 서버 URL 교체
      // 백엔드 createBoard가 boardId(Integer) 직접 반환
      const boardId = typeof created === 'number' ? created : created?.boardId;
      if (pendingImages.length > 0 && boardId) {
        const files = pendingImages.map((p) => p.file);
        const uploadResult = await fileApi.upload('BOARD', boardId, files);
        const uploaded = uploadResult?.files ?? uploadResult ?? [];

        // DOM 파서로 blob URL을 서버 URL로 교체
        const parser = new DOMParser();
        const doc = parser.parseFromString(writeContent, 'text/html');
        const imgs = doc.querySelectorAll('img[data-pending-img]');
        imgs.forEach((img, i) => {
          const file = uploaded[i];
          if (file) {
            // blob URL 해제
            URL.revokeObjectURL(img.src);
            img.src = toApiImageUrl(file.viewUrl);
            img.removeAttribute('data-pending-img');
          }
        });
        const finalHtml = doc.body.innerHTML;

        // 3. 교체된 HTML로 업데이트
        await communityApi.updateBoard(boardId, {
          boardTitle: title,
          boardCtnt: finalHtml,
          anonymity: anonymous ? 'Y' : 'N',
        });
      }

      // blob URL 메모리 해제
      pendingImages.forEach((p) => URL.revokeObjectURL(p.blobUrl));
      setWriteTitle('');
      setWriteContent('');
      setAnonymous(false);
      setPendingImages([]);
      setShowWriter(false);
      if (page === 1) await load();
      else setPage(1);
    } catch (e) {
      setError(e?.message || '게시글 작성에 실패했습니다.');
    } finally {
      setSubmitting(false);
    }
  };

  const [likePendingIds, setLikePendingIds] = useState(new Set());

  const handleLike = async (e, itemId) => {
    e.stopPropagation();
    if (!isLoggedIn) return;
    if (likePendingIds.has(itemId)) return;
    setLikePendingIds((prev) => new Set([...prev, itemId]));

    if (activeTab === 'REVIEW') {
      const item = items.find((i) => i.reviewId === itemId);
      if (!item) {
        setLikePendingIds((prev) => {
          const s = new Set(prev);
          s.delete(itemId);
          return s;
        });
        return;
      }
      const wasLiked = item.likedByMe;
      setItems((prev) =>
        prev.map((i) =>
          i.reviewId === itemId
            ? {
                ...i,
                likedByMe: !wasLiked,
                likeCount: (i.likeCount ?? 0) + (wasLiked ? -1 : 1),
              }
            : i
        )
      );
      try {
        if (wasLiked) await reviewApi.unlikeReview(itemId);
        else await reviewApi.likeReview(itemId);
      } catch (err) {
        console.warn('review like error:', err?.message);
        setItems((prev) =>
          prev.map((i) =>
            i.reviewId === itemId
              ? {
                  ...i,
                  likedByMe: wasLiked,
                  likeCount: (i.likeCount ?? 0) + (wasLiked ? 1 : -1),
                }
              : i
          )
        );
      } finally {
        setLikePendingIds((prev) => {
          const s = new Set(prev);
          s.delete(itemId);
          return s;
        });
      }
      return;
    }

    const item = items.find((i) => (i.boardId ?? i.id) === itemId);
    if (!item) {
      setLikePendingIds((prev) => {
        const s = new Set(prev);
        s.delete(itemId);
        return s;
      });
      return;
    }
    const wasLiked = item.likedByMe;
    setItems((prev) =>
      prev.map((i) =>
        (i.boardId ?? i.id) === itemId
          ? {
              ...i,
              likedByMe: !wasLiked,
              likeCount: (i.likeCount ?? 0) + (wasLiked ? -1 : 1),
            }
          : i
      )
    );
    try {
      if (wasLiked) await communityApi.unlikeBoard(itemId);
      else await communityApi.likeBoard(itemId);
    } catch (err) {
      console.warn('board like error:', err?.message);
      setItems((prev) =>
        prev.map((i) =>
          (i.boardId ?? i.id) === itemId
            ? {
                ...i,
                likedByMe: wasLiked,
                likeCount: (i.likeCount ?? 0) + (wasLiked ? 1 : -1),
              }
            : i
        )
      );
    } finally {
      setLikePendingIds((prev) => {
        const s = new Set(prev);
        s.delete(itemId);
        return s;
      });
    }
  };

  const handleBoardClick = (boardId) => {
    const qs = searchParams.toString();
    const item = items.find((i) => (i.boardId ?? i.id) === boardId);
    navigate(`/community/${boardId}${qs ? `?${qs}` : ''}`, {
      state: {
        likedByMe: item?.likedByMe ?? false,
        likeCount: item?.likeCount ?? 0,
      },
    });
  };

  return (
    <div className={styles.page}>
      <Header />

      {/* ══ HERO — Support 동일 방식 ════════════════════════ */}
      <section className={styles.heroSection}>
        <div
          className={styles.heroBg}
          style={{
            backgroundImage: `url(${heroImg})`,
            opacity: heroFade ? 1 : 0,
          }}
        />
        <div className={styles.heroOverlay} />
        <div className={styles.heroSideLine} aria-hidden="true" />
        <div className={styles.heroContent}>
          <div className={styles.heroInner}>
            <span className={styles.heroEyebrow}>{EYEBROW_MAP[activeTab]}</span>
            <div className={styles.heroLine} aria-hidden="true" />
            <h1 className={styles.heroTitle}>{TITLE_MAP[activeTab]}</h1>
            <p className={styles.heroSub}>{SUBTITLE_MAP[activeTab]}</p>
          </div>
        </div>
        <div className={styles.heroFade} aria-hidden="true" />
      </section>

      {/* ══ 탭 네비게이션 — Support 동일 방식 ══════════════ */}
      <nav className={styles.tabBar} aria-label="커뮤니티 메뉴">
        <div className={styles.tabInner}>
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              className={`${styles.tabBtn} ${activeTab === t.key ? styles.tabBtnActive : ''}`}
              onClick={() => handleTabChange(t.key)}
              aria-current={activeTab === t.key ? 'page' : undefined}
            >
              {t.label}
            </button>
          ))}
        </div>
      </nav>

      <main className={styles.main}>
        {/* ── 페이지 제목 ── */}
        <div className={styles.pageHead}>
          <h2 className={styles.pageTitle}>{TITLE_MAP[activeTab]}</h2>
        </div>

        {/* 글쓰기 버튼 */}
        {canOpenWriter && (
          <div className={styles.topBar}>
            <button
              type="button"
              className={styles.writeToggleBtn}
              onClick={() => setShowWriter((v) => !v)}
            >
              {showWriter ? '✕ 닫기' : '✏ 글쓰기'}
            </button>
          </div>
        )}

        {/* 검색 바 */}
        <div className={styles.searchBar}>
          <select
            className={styles.searchSelect}
            value={searchType}
            onChange={(e) => setSearchType(e.target.value)}
          >
            <option value="title">제목</option>
            <option value="nickname">닉네임</option>
          </select>
          <input
            className={styles.searchInput}
            type="text"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="검색어를 입력하세요"
          />
          <button
            type="button"
            className={styles.searchBtn}
            onClick={handleSearch}
          >
            검색
          </button>
          {activeSearch.keyword && (
            <button
              type="button"
              className={styles.searchResetBtn}
              onClick={handleSearchReset}
            >
              초기화
            </button>
          )}
        </div>

        {/* 글쓰기 폼 */}
        {canOpenWriter && showWriter && (
          <section className={styles.writerBox}>
            <div className={styles.writerRow}>
              <label className={styles.writerLabel}>분류</label>
              <div className={styles.writerFixed}>
                {activeTab === 'ALL' ? '자유' : typeLabel(activeTab)}
              </div>
            </div>
            <div className={styles.writerRow}>
              <label className={styles.writerLabel}>제목</label>
              <input
                className={styles.writerInput}
                value={writeTitle}
                onChange={(e) => setWriteTitle(e.target.value)}
                maxLength={200}
                disabled={submitting}
                placeholder="제목을 입력하세요"
              />
            </div>
            <div className={`${styles.writerRow} ${styles.writerRowContent}`}>
              <label className={styles.writerLabel}>내용</label>
              <div className={styles.editorWrapper} ref={editorContainerRef}>
                <RichEditor onChange={setWriteContent} disabled={submitting} />
                <div className={styles.editorFooter}>
                  <InlineImageBtn
                    onInsert={handleInsertImage}
                    disabled={submitting}
                  />
                  {pendingImages.length > 0 && (
                    <span className={styles.imgCount}>
                      이미지 {pendingImages.length}개
                    </span>
                  )}
                </div>
              </div>
            </div>
            {error && <div className={styles.error}>{error}</div>}
            <div className={styles.anonymousRow}>
              <label className={styles.anonymousLabel}>
                <input
                  type="checkbox"
                  className={styles.anonymousCheck}
                  checked={anonymous}
                  onChange={(e) => setAnonymous(e.target.checked)}
                  disabled={submitting}
                />
                익명으로 작성
              </label>
            </div>
            <div className={styles.writerActions}>
              <button
                type="button"
                className={styles.cancelWriteBtn}
                onClick={() => setShowWriter(false)}
                disabled={submitting}
              >
                취소
              </button>
              <button
                type="button"
                className={styles.submitBtn}
                onClick={submitPost}
                disabled={submitting || !writeTitle.trim() || isBanned}
              >
                {submitting ? '등록 중...' : '등록'}
              </button>
            </div>
          </section>
        )}

        {showWriter && isBanned && (
          <div className={styles.error}>
            정지(banned) 상태의 계정은 커뮤니티 글을 작성할 수 없습니다.
          </div>
        )}
        {!showWriter && error && <div className={styles.error}>{error}</div>}

        {/* 목록 */}
        {loading ? (
          <div className={styles.state}>불러오는 중...</div>
        ) : items.length === 0 ? (
          <div className={styles.state}>게시글이 없습니다.</div>
        ) : (
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th className={styles.colType}>분류</th>
                  <th>제목</th>
                  <th className={styles.colAuthor}>작성자</th>
                  <th className={styles.colDate}>작성일</th>
                  <th className={styles.colNum}>조회</th>
                  <th className={styles.colNum}>좋아요</th>
                  {isAdmin && <th className={styles.colNum}>관리</th>}
                </tr>
              </thead>
              <tbody>
                {items.map((item, idx) => {
                  const boardId = item?.boardId ?? item?.id ?? idx;
                  const tkey = typeKey(item?.code ?? item?.boardType);
                  return (
                    <tr key={boardId} className={styles.row}>
                      <td>
                        <span
                          className={`${styles.typeBadge} ${styles['type_' + tkey]}`}
                        >
                          {typeLabel(item?.code ?? item?.boardType)}
                        </span>
                      </td>
                      <td className={styles.titleCell}>
                        <button
                          type="button"
                          className={styles.titleBtn}
                          onClick={() => {
                            if (activeTab === 'REVIEW') {
                              setReviewModal({
                                mode: 'detail',
                                reviewId: item.reviewId,
                              });
                            } else {
                              handleBoardClick(boardId);
                            }
                          }}
                        >
                          {activeTab === 'REVIEW'
                            ? item?.reviewTitle ||
                              item?.reviewCtnt?.slice(0, 40) ||
                              '(내용 없음)'
                            : (item?.boardTitle ??
                              item?.title ??
                              '(제목 없음)')}
                          {(item?.fileCk === 'Y' ||
                            item?.files?.length > 0) && (
                            <span className={styles.fileIcon}>📎</span>
                          )}
                        </button>
                      </td>
                      <td className={styles.authorCell}>
                        {activeTab === 'REVIEW' ? (
                          <span
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 4,
                            }}
                          >
                            <span style={{ color: '#d9ad5b', fontSize: 12 }}>
                              {'★'.repeat(item.rating ?? 0)}
                            </span>
                            <span style={{ fontSize: 12, color: '#9a8c70' }}>
                              {item?.userId ?? '-'}
                            </span>
                          </span>
                        ) : isAdmin && item?.realUserId ? (
                          <button
                            type="button"
                            className={styles.titleBtn}
                            onClick={() =>
                              setUserStatusModalId(item.realUserId)
                            }
                            title="회원 정보/상태 변경"
                          >
                            {item.realUserNickname ?? item.realUserId}
                          </button>
                        ) : (
                          <span>{item?.userId ?? '-'}</span>
                        )}
                      </td>
                      <td className={styles.dateCell}>
                        {formatDate(item?.createdAt)}
                      </td>
                      <td className={styles.numCell}>{item?.readCount ?? 0}</td>
                      <td className={styles.numCell}>
                        <button
                          type="button"
                          disabled={
                            !isLoggedIn ||
                            likePendingIds.has(
                              activeTab === 'REVIEW' ? item.reviewId : boardId
                            )
                          }
                          title={
                            !isLoggedIn
                              ? '로그인 후 좋아요를 누를 수 있습니다.'
                              : ''
                          }
                          className={`${styles.likeBtn} ${item?.likedByMe ? styles.likeBtnActive : ''} ${!isLoggedIn ? styles.likeBtnDisabled : ''}`}
                          onClick={(e) =>
                            handleLike(
                              e,
                              activeTab === 'REVIEW' ? item.reviewId : boardId
                            )
                          }
                        >
                          {item?.likedByMe ? '❤️' : '🤍'} {item?.likeCount ?? 0}
                        </button>
                      </td>
                      {isAdmin && (
                        <td style={{ textAlign: 'center' }}>
                          <button
                            type="button"
                            onClick={(e) => handleAdminDeleteBoard(boardId, e)}
                            style={{
                              padding: '4px 10px',
                              borderRadius: 6,
                              background: '#fee2e2',
                              color: '#b91c1c',
                              border: '1px solid #fca5a5',
                              cursor: 'pointer',
                              fontSize: 12,
                              fontWeight: 600,
                            }}
                          >
                            삭제
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* 페이지네이션 */}
        {totalPages > 1 && (
          <div className={styles.pagination}>
            <button
              type="button"
              className={styles.pageBtn}
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              {'<'}
            </button>
            {pageButtons.map((p) => (
              <button
                key={p}
                type="button"
                className={`${styles.pageBtn} ${p === page ? styles.pageBtnActive : ''}`}
                onClick={() => setPage(p)}
              >
                {p}
              </button>
            ))}
            <button
              type="button"
              className={styles.pageBtn}
              disabled={page >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            >
              {'>'}
            </button>
          </div>
        )}
      </main>
      <Footer />

      {reviewModal && (
        <ReviewModal
          mode={reviewModal.mode}
          reviewId={reviewModal.reviewId}
          roomId={reviewModal.roomId}
          onClose={() => setReviewModal(null)}
          onSaved={() => {
            setReviewModal(null);
            load();
          }}
        />
      )}

      {isAdmin && userStatusModalId && (
        <UserStatusModal
          userId={userStatusModalId}
          currentUserId={user?.userId}
          onClose={() => setUserStatusModalId(null)}
          onSaved={() => load()}
        />
      )}
    </div>
  );
}

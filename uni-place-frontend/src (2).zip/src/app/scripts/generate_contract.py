#!/usr/bin/env python3
"""
generate_contract.py
계약서 PNG 템플릿 위에 계약 정보 + 서명 이미지를 합성하여 JPG로 저장

필요 라이브러리: pip install Pillow
(pdf2image, poppler 불필요!)

사용법:
  python3 generate_contract.py \
    --template /path/to/contract_template.png \
    --output   /path/to/output.jpg \
    --data     '{"building_addr":"서울...","room_no":"101",...}' \
    [--sign_img /path/to/sign.png]
"""

import argparse
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

# ── 상수 ───────────────────────────────────────────────────────────
UNIFONT_PATH = "/usr/share/fonts/opentype/unifont/unifont.otf"
# Windows 경우 아래 경로 중 하나 사용:
# UNIFONT_PATH = "C:/Windows/Fonts/malgun.ttf"       # 맑은 고딕
# UNIFONT_PATH = "C:/Windows/Fonts/gulim.ttc"        # 굴림

IMG_W, IMG_H = 1240, 1753   # contract_template.png 크기 (150dpi 기준)
PDF_W, PDF_H = 595.0, 841.0  # PDF 포인트 크기

BLACK = (0, 0, 0)
BLUE  = (10, 10, 180)
FONT_SM = 12
FONT_MD = 14


def scale(pdf_x: float, pdf_y: float):
    """PDF 좌표 → PNG 픽셀 좌표 변환"""
    return int(pdf_x * IMG_W / PDF_W), int(pdf_y * IMG_H / PDF_H)


def find_font(size: int):
    """사용 가능한 한글 폰트 탐색"""
    candidates = [
        UNIFONT_PATH,
        "C:/Windows/Fonts/malgun.ttf",    # 맑은 고딕 (Windows)
        "C:/Windows/Fonts/gulim.ttc",     # 굴림
        "C:/Windows/Fonts/batang.ttc",    # 바탕
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",   # Linux Nanum
        "/System/Library/Fonts/AppleGothic.ttf",              # Mac
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    print(f"[WARN] 한글 폰트를 찾지 못했습니다. 기본 폰트 사용", file=sys.stderr)
    return ImageFont.load_default()


def generate(template_path: str, output_path: str, data: dict, sign_img_path: str = None):
    # 1. PNG 템플릿 로드
    img: Image.Image = Image.open(template_path).convert("RGB")
    # 템플릿 크기가 다르면 자동 조정
    global IMG_W, IMG_H
    IMG_W, IMG_H = img.size

    draw = ImageDraw.Draw(img)

    # 2. 폰트
    f_sm = find_font(FONT_SM)
    f_md = find_font(FONT_MD)

    def t(px, py, text, font=None, fill=BLACK):
        if not text:
            return
        x, y = scale(px, py)
        draw.text((x, y), str(text), font=font or f_sm, fill=fill)

    # ── 계약 데이터 ──────────────────────────────────────────────
    building_addr  = data.get("building_addr", "")
    room_no        = data.get("room_no", "")
    room_size      = data.get("room_size", "")
    deposit        = data.get("deposit", "")
    rent_price     = data.get("rent_price", "")
    payment_day    = data.get("payment_day", "")
    deliver_year   = data.get("deliver_year", "")
    deliver_month  = data.get("deliver_month", "")
    deliver_day    = data.get("deliver_day", "")
    end_year       = data.get("end_year", "")
    end_month      = data.get("end_month", "")
    end_day        = data.get("end_day", "")
    sign_year      = data.get("sign_year", "")
    sign_month     = data.get("sign_month", "")
    sign_day       = data.get("sign_day", "")
    lessor_addr    = data.get("lessor_addr", "")
    lessor_rrn     = data.get("lessor_rrn", "")
    lessor_tel     = data.get("lessor_tel", "")
    lessor_nm      = data.get("lessor_nm", "")
    lessee_addr    = data.get("lessee_addr", "")
    lessee_rrn     = data.get("lessee_rrn", "")
    lessee_tel     = data.get("lessee_tel", "")
    lessee_nm      = data.get("lessee_nm", "")

    # ── 1. 소재지 ────────────────────────────────────────────────
    addr_text = f"{building_addr}  {room_no}호" if room_no else building_addr
    t(160, 121, addr_text)

    # ── 2. 임대할 부분 면적 ──────────────────────────────────────
    if room_size:
        t(350, 185, f"{room_size}㎡")

    # ── 3. 보증금 ────────────────────────────────────────────────
    if deposit:
        t(160, 224, f"{deposit}원")

    # ── 4. 차임(월세) + 납부일 ───────────────────────────────────
    if rent_price:
        t(160, 283, f"{rent_price}원")
    if payment_day:
        t(474, 283, str(payment_day))

    # ── 5. 제2조 인도일 ──────────────────────────────────────────
    t(396, 302, deliver_year,  fill=BLUE)
    t(435, 302, deliver_month, fill=BLUE)
    t(465, 302, deliver_day,   fill=BLUE)

    # ── 6. 제2조 종료일 ──────────────────────────────────────────
    t(256, 312, end_year,  fill=BLUE)
    t(295, 312, end_month, fill=BLUE)
    t(325, 312, end_day,   fill=BLUE)

    # ── 7. 계약 서명 날짜 ────────────────────────────────────────
    t(444, 581, sign_year)
    t(478, 581, sign_month)
    t(506, 581, sign_day)

    # ── 8. 임대인 ────────────────────────────────────────────────
    t(165, 593, lessor_addr)
    t(165, 608, lessor_rrn)
    t(338, 608, lessor_tel)
    t(450, 608, lessor_nm, font=f_md)

    # ── 9. 임차인 ────────────────────────────────────────────────
    t(165, 641, lessee_addr)
    t(165, 657, lessee_rrn)
    t(338, 657, lessee_tel)
    t(450, 657, lessee_nm, font=f_md)

    # ── 10. 서명 이미지 합성 ─────────────────────────────────────
    if sign_img_path and Path(sign_img_path).exists():
        try:
            sign_raw = Image.open(sign_img_path).convert("RGBA")
            sx, sy = scale(490, 653)
            sw, sh = scale(60, 22)
            sign_resized = sign_raw.resize((sw, sh), Image.LANCZOS)
            img.paste(sign_resized, (sx, sy), sign_resized.split()[3])
        except Exception as e:
            print(f"[WARN] 서명 이미지 합성 실패: {e}", file=sys.stderr)

    # ── 11. 저장 ─────────────────────────────────────────────────
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(str(out), "JPEG", quality=92, optimize=True)
    print(f"OK:{out}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--output",   required=True)
    parser.add_argument("--data",     required=True)
    parser.add_argument("--sign_img", default=None)
    args = parser.parse_args()

    try:
        data = json.loads(args.data)
    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON 파싱 실패: {e}", file=sys.stderr)
        sys.exit(1)

    generate(args.template, args.output, data, args.sign_img)


if __name__ == "__main__":
    main()
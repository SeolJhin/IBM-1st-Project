import React, { useEffect, useMemo, useState } from 'react';
import { adminApi } from '../../admin/api/adminApi';

/**
 * UserStatusModal
 * - Community(관리자 모드)에서 userId 클릭 시: 유저 정보 조회 + 상태(active/inactive/banned) 변경
 *
 * NOTE: 실제 권한/차단은 백엔드에서 강제해야 합니다.
 */
export default function UserStatusModal({ open, userId, onClose, onUpdated }) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [user, setUser] = useState(null);
  const [nextStatus, setNextStatus] = useState('ACTIVE');

  const statusOptions = useMemo(
    () => [
      { value: 'ACTIVE', label: 'ACTIVE' },
      { value: 'INACTIVE', label: 'INACTIVE' },
      { value: 'BANNED', label: 'BANNED' },
    ],
    []
  );

  useEffect(() => {
    if (!open || !userId) return;
    let alive = true;

    (async () => {
      try {
        setLoading(true);
        setError('');
        const data = await adminApi.getUserDetail(userId);
        if (!alive) return;
        setUser(data);
        const current = (data?.status || data?.userSt || data?.state || 'ACTIVE').toString().toUpperCase();
        setNextStatus(current);
      } catch (e) {
        if (!alive) return;
        setError(e?.message || '유저 정보를 불러오지 못했습니다.');
        setUser(null);
      } finally {
        if (alive) setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [open, userId]);

  const handleSave = async () => {
    if (!userId) return;
    try {
      setSaving(true);
      setError('');
      await adminApi.updateUserStatus(userId, nextStatus);
      onUpdated?.(nextStatus);
      onClose?.();
    } catch (e) {
      setError(e?.message || '상태 변경에 실패했습니다.');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div style={styles.overlay} onMouseDown={onClose} role="presentation">
      <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div style={styles.header}>
          <div style={styles.title}>User 관리</div>
          <button type="button" onClick={onClose} style={styles.closeBtn} aria-label="close">
            ✕
          </button>
        </div>

        <div style={styles.body}>
          {loading ? (
            <div>불러오는 중...</div>
          ) : error ? (
            <div style={styles.error}>{error}</div>
          ) : (
            <>
              <div style={styles.row}>
                <div style={styles.label}>User ID</div>
                <div style={styles.value}>{userId}</div>
              </div>

              <div style={styles.row}>
                <div style={styles.label}>Email</div>
                <div style={styles.value}>{user?.email || user?.userEmail || '-'}</div>
              </div>

              <div style={styles.row}>
                <div style={styles.label}>Name</div>
                <div style={styles.value}>{user?.name || user?.userNm || '-'}</div>
              </div>

              <div style={styles.row}>
                <div style={styles.label}>Status</div>
                <div style={styles.value}>
                  <select
                    value={nextStatus}
                    onChange={(e) => setNextStatus(e.target.value)}
                    style={styles.select}
                    disabled={saving}
                  >
                    {statusOptions.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={styles.hint}>
                * BANNED 유저는 커뮤니티 글/댓글 작성이 불가하도록 백엔드에서도 반드시 차단해야 합니다.
              </div>
            </>
          )}
        </div>

        <div style={styles.footer}>
          <button type="button" onClick={onClose} style={styles.secondaryBtn} disabled={saving}>
            닫기
          </button>
          <button type="button" onClick={handleSave} style={styles.primaryBtn} disabled={saving || loading || !!error}>
            {saving ? '저장 중...' : '상태 저장'}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.45)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
    padding: 16,
  },
  modal: {
    width: 'min(560px, 100%)',
    background: '#fff',
    borderRadius: 12,
    boxShadow: '0 12px 30px rgba(0,0,0,0.25)',
    overflow: 'hidden',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '14px 16px',
    borderBottom: '1px solid #eee',
  },
  title: { fontSize: 18, fontWeight: 700 },
  closeBtn: {
    border: 'none',
    background: 'transparent',
    fontSize: 18,
    cursor: 'pointer',
    padding: 6,
    lineHeight: 1,
  },
  body: { padding: 16 },
  row: { display: 'grid', gridTemplateColumns: '120px 1fr', gap: 10, padding: '8px 0' },
  label: { fontWeight: 700, color: '#333' },
  value: { color: '#222', wordBreak: 'break-word' },
  select: { padding: '8px 10px', borderRadius: 8, border: '1px solid #ddd', minWidth: 160 },
  hint: { marginTop: 12, fontSize: 12, color: '#666' },
  error: { color: '#b00020' },
  footer: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: 10,
    padding: '12px 16px',
    borderTop: '1px solid #eee',
    background: '#fafafa',
  },
  primaryBtn: {
    padding: '10px 12px',
    borderRadius: 10,
    border: '1px solid #111',
    background: '#111',
    color: '#fff',
    cursor: 'pointer',
  },
  secondaryBtn: {
    padding: '10px 12px',
    borderRadius: 10,
    border: '1px solid #ddd',
    background: '#fff',
    cursor: 'pointer',
  },
};

import { fetchWithAuthRetry } from '../../../app/http/apiBase';

async function request(
  path,
  { method = 'GET', body, headers = {}, auth = false } = {}
) {
  const res = await fetchWithAuthRetry(
    path,
    {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      credentials: 'same-origin',
      body: body ? JSON.stringify(body) : undefined,
    },
    { auth }
  );

  if (res.status === 204) return null;

  const contentType = res.headers.get('content-type') || '';
  const isJson = contentType.includes('application/json');
  const payload = isJson
    ? await res.json().catch(() => null)
    : await res.text().catch(() => null);

  const api =
    payload && typeof payload === 'object' && 'success' in payload
      ? payload
      : null;

  if (!res.ok || (api && api.success === false)) {
    const message =
      (api && api.message) ||
      (payload && payload.message) ||
      (typeof payload === 'string' ? payload : 'Request failed.');
    const error = new Error(message);
    error.status = res.status;
    error.errorCode = api?.errorCode;
    error.data = payload;
    throw error;
  }

  return api ? api.data : payload;
}

export const authApi = {
  signup: (data) =>
    request('/auth/signup', {
      method: 'POST',
      body: data,
    }),

  login: ({ userEmail, userPwd, deviceId }) =>
    request('/auth/login', {
      method: 'POST',
      body: { userEmail, userPwd, deviceId },
    }),

  refresh: ({ refreshToken, deviceId }) =>
    request('/auth/refresh', {
      method: 'POST',
      body: { refreshToken, deviceId },
    }),

  logout: ({ refreshToken, deviceId }) =>
    request('/auth/logout', {
      method: 'POST',
      body: { refreshToken, deviceId },
      auth: true,
    }),

  logoutAll: () =>
    request('/auth/logout-all', {
      method: 'POST',
      auth: true,
    }),

  kakaoComplete: ({ signupToken, userNm, userBirth, userTel }) =>
    request('/auth/oauth2/kakao/complete', {
      method: 'POST',
      body: { signupToken, userNm, userBirth, userTel },
    }),

  googleComplete: ({ signupToken, userNm, userBirth, userTel }) =>
    request('/auth/oauth2/google/complete', {
      method: 'POST',
      body: { signupToken, userNm, userBirth, userTel },
    }),

  me: () => request('/users/me', { auth: true }),

  updateMe: (patch) =>
    request('/users/me', { method: 'PATCH', body: patch, auth: true }),

  deleteMe: () => request('/users/me', { method: 'DELETE', auth: true }),
};

// App.js
import React from 'react';
import './app/styles/globals.css';

import { Routes, Route, Navigate } from 'react-router-dom';

import ScrollToTop from './shared/components/ScrollToTop';
import Home from './shared/pages/Home';
import About from './shared/pages/About';

// ── 유저 ──────────────────────────────────────────────────────
import Login from './features/user/pages/Login';
import Signup from './features/user/pages/Signup';
import MemberInfo from './features/user/pages/MemberInfo';

// ── Property ──────────────────────────────────────────────────
import RoomList from './features/property/pages/RoomList';
import RoomDetail from './features/property/pages/RoomDetail';
import SpaceDetail from './features/property/pages/SpaceDetail';
import BuildingDetail from './features/property/pages/BuildingDetail';

// ── 예약 ──────────────────────────────────────────────────────
import SpaceReservationCreate from './features/reservation/pages/SpaceReservationCreate';
import SpaceReservationList from './features/reservation/pages/SpaceReservationList';
import TourReservationCreate from './features/reservation/pages/TourReservationCreate';
import TourReservationList from './features/reservation/pages/TourReservationList';

// ── 리뷰 ──────────────────────────────────────────────────────
import ReviewWrite from './features/review/pages/ReviewWrite';
import MyReviewsList from './features/review/pages/MyReviewsList';
import MyReviewsDetail from './features/review/pages/MyReviewsDetail';

// ── 어드민 ────────────────────────────────────────────────────
import RequireAuth from './app/router/guards/RequireAuth';
import RequireRole from './app/router/guards/RequireRole';
import AdminShell from './features/admin/components/AdminShell';
import AdminInfo from './features/admin/pages/AdminInfo';
import AdminUserList from './features/admin/pages/user/AdminUserList';
import AdminSpaceList from './features/admin/pages/property/AdminSpaceList';
import AdminTourReservationList from './features/admin/pages/reservation/AdminTourReservationList';
import AdminSpaceReservationList from './features/admin/pages/reservation/AdminSpaceReservationList';
import AdminContractList from './features/admin/pages/contract/AdminContractList';
import AdminBannerList from './features/admin/pages/system/AdminBannerList';
import AdminRoomServiceOrderList from './features/admin/pages/roomservice/AdminRoomServiceOrderList';

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        {/* ── 공통 ── */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About variant="about" />} />
        <Route path="/community" element={<About variant="community" />} />
        <Route path="/guide" element={<About variant="guide" />} />
        <Route path="/news" element={<About variant="news" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/me" element={<MemberInfo />} />

        {/* ── Property ── */}
        <Route path="/rooms" element={<RoomList />} />
        <Route path="/rooms/:roomId" element={<RoomDetail />} />
        <Route path="/spaces/:spaceId" element={<SpaceDetail />} />
        <Route path="/buildings/:buildingId" element={<BuildingDetail />} />
        {/* /buildings → /rooms 건물 탭으로 리다이렉트 */}
        <Route
          path="/buildings"
          element={
            <Navigate to="/rooms" state={{ tab: 'buildings' }} replace />
          }
        />
        {/* /membership → /rooms 리다이렉트 */}
        <Route path="/membership" element={<Navigate to="/rooms" replace />} />

        {/* ── 예약 ── */}
        <Route
          path="/reservations/space/create"
          element={<SpaceReservationCreate />}
        />
        <Route
          path="/reservations/space/list"
          element={<SpaceReservationList />}
        />
        <Route
          path="/reservations/tour/create"
          element={<TourReservationCreate />}
        />
        <Route
          path="/reservations/tour/list"
          element={<TourReservationList />}
        />

        {/* ── 리뷰 ── */}
        <Route path="/reviews/write" element={<ReviewWrite />} />
        <Route path="/reviews/:reviewId/edit" element={<ReviewWrite />} />
        <Route path="/reviews/my" element={<MyReviewsList />} />
        <Route path="/reviews/:reviewId" element={<MyReviewsDetail />} />

        {/* ── 어드민 (로그인 + ADMIN 역할 필요) ── */}
        <Route element={<RequireAuth />}>
          <Route element={<RequireRole allow={['admin']} />}>
            <Route path="/admin" element={<AdminShell />}>
              <Route index element={<AdminInfo />} />
              <Route path="users" element={<AdminUserList />} />
              <Route path="property/spaces" element={<AdminSpaceList />} />
              <Route
                path="reservation/tours"
                element={<AdminTourReservationList />}
              />
              <Route
                path="reservation/spaces"
                element={<AdminSpaceReservationList />}
              />
              <Route
                path="contract/contracts"
                element={<AdminContractList />}
              />
              <Route path="system/banners" element={<AdminBannerList />} />
              <Route
                path="roomservice/orders"
                element={<AdminRoomServiceOrderList />}
              />
            </Route>
          </Route>
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

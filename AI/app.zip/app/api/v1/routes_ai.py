"""
AI 라우터 — UNI PLACE FastAPI
위치: AI/app/api/v1/routes_ai.py

Spring application.properties 의 ai.fastapi.* 경로와 1:1 매핑.
voice-assistant 엔드포인트는 Whisper STT + MeloTTS 실제 연동.
"""
import io
import logging
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, File, Form, UploadFile, HTTPException
from fastapi.responses import JSONResponse, Response

from app.api.v1.executor import ERROR_RESPONSES, execute_ai_request, parse_ai_request
from app.schemas.ai_request import AiRequest
from app.schemas.ai_response import AiResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/ai", tags=["ai"])

# ── Voice Pipeline 싱글톤 (지연 로드) ────────────────────────────────────────
_voice_pipeline = None

def get_voice_pipeline():
    global _voice_pipeline
    if _voice_pipeline is None:
        try:
            from app.voice.pipeline.voice_pipeline import VoicePipeline
            _voice_pipeline = VoicePipeline()
            logger.info("VoicePipeline 로드 완료 ✓")
        except Exception as e:
            logger.warning(f"VoicePipeline 로드 실패 (STT/TTS 비활성): {e}")
    return _voice_pipeline


# ── fallback (Spring: execute-path) ──────────────────────────────────────────
@router.post("/execute", response_model=AiResponse, responses=ERROR_RESPONSES)
def execute(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse):
        return parsed
    return execute_ai_request(parsed)


# ── chat/general-qa ───────────────────────────────────────────────────────────
@router.post("/chat/general-qa", response_model=AiResponse, responses=ERROR_RESPONSES)
def general_qa(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "GENERAL_QA")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse):
        return parsed
    return execute_ai_request(parsed)


# ── chat/agent-chatbot ────────────────────────────────────────────────────────
@router.post("/chat/agent-chatbot", response_model=AiResponse, responses=ERROR_RESPONSES)
def agent_chatbot(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    """멀티턴 AI 에이전트 챗봇. slots 에 history: [{role, content}, ...] 포함 가능."""
    payload.setdefault("intent", "GENERAL_QA")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse):
        return parsed
    return execute_ai_request(parsed)


# ── chat/voice-assistant (JSON — STT 결과 텍스트로 전달) ─────────────────────
@router.post("/chat/voice-assistant", response_model=AiResponse, responses=ERROR_RESPONSES)
def voice_assistant(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    """
    음성 어시스턴트 — 텍스트 입력 버전.

    React ChatBot → Spring → 여기로 옴.
    slots.transcribed_text 또는 payload.transcribed_text 를 prompt 로 승격.

    Request body 예시:
        {
          "userId": "123",
          "userSegment": "user",
          "prompt": "",
          "slots": {
            "transcribed_text": "방 예약하고 싶어요",
            "language": "ko",
            "history": [{"role": "user", "content": "..."}, ...]
          }
        }
    """
    if not payload.get("prompt"):
        slots = payload.get("slots") or {}
        transcribed = slots.get("transcribed_text") or payload.get("transcribed_text", "")
        payload["prompt"] = transcribed
    payload.setdefault("intent", "GENERAL_QA")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse):
        return parsed
    return execute_ai_request(parsed)


# ── voice/stt — 오디오 파일 → 텍스트 (STT 전용 엔드포인트) ──────────────────
@router.post("/voice/stt")
async def speech_to_text(
    file: UploadFile = File(..., description="오디오 파일 (wav, mp3, m4a, webm)"),
    language: Optional[str] = Form(None, description="언어 코드 (None=자동감지)"),
):
    """
    음성 파일 → 텍스트 변환 (Whisper STT)

    React ChatBot 마이크 버튼 → 여기로 직접 호출 가능.
    또는 voice-pipeline server.py 의 /stt 를 통해 호출.

    Response:
        {
          "text": "인식된 텍스트",
          "language": "ko",
          "language_probability": 0.99,
          "duration_s": 3.2
        }
    """
    pipeline = get_voice_pipeline()
    if pipeline is None:
        raise HTTPException(503, "STT 서비스 미준비 (faster-whisper 설치 필요)")

    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(413, "파일 크기 초과 (최대 50MB)")

    suffix = Path(file.filename or "audio.wav").suffix or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = Path(tmp.name)

    try:
        result = pipeline.stt_only(tmp_path, language=language)
    except Exception as e:
        logger.exception("STT 처리 오류")
        raise HTTPException(500, str(e))
    finally:
        tmp_path.unlink(missing_ok=True)

    return {
        "text": result.text,
        "language": result.language,
        "language_probability": result.language_probability,
        "duration_s": getattr(result, "duration_s", 0.0),
        "processing_time_s": result.processing_time_s,
    }


# ── voice/tts — 텍스트 → 오디오 파일 (TTS 전용 엔드포인트) ──────────────────
@router.post("/voice/tts")
async def text_to_speech(
    text: str = Form(...),
    lang: Optional[str] = Form(None),
    speed: float = Form(1.0),
    output_format: str = Form("wav"),
):
    """
    텍스트 → 음성 합성 (MeloTTS)

    React ChatBot AI 응답 → 음성 재생 시 사용.

    Response: audio/wav (또는 mp3/ogg) 바이너리
    """
    pipeline = get_voice_pipeline()
    if pipeline is None:
        raise HTTPException(503, "TTS 서비스 미준비 (MeloTTS 설치 필요)")

    if not text.strip():
        raise HTTPException(400, "텍스트가 비어있습니다")
    if len(text) > 5000:
        raise HTTPException(400, "텍스트 길이 초과 (최대 5000자)")

    try:
        result = pipeline.tts_only(text, lang=lang, speed=speed, output_format=output_format)
    except Exception as e:
        logger.exception("TTS 처리 오류")
        raise HTTPException(500, str(e))

    media_types = {"wav": "audio/wav", "mp3": "audio/mpeg", "ogg": "audio/ogg"}
    return Response(
        content=result.audio_bytes,
        media_type=media_types.get(output_format, "audio/wav"),
        headers={
            "X-Duration-S": str(result.duration_s),
            "X-Processing-Time": str(result.processing_time_s),
        },
    )


# ── voice/pipeline — STT + AI + TTS 풀 파이프라인 ───────────────────────────
@router.post("/voice/pipeline")
async def voice_pipeline(
    file: UploadFile = File(...),
    language: Optional[str] = Form(None),
    tts_speed: float = Form(1.0),
    output_format: str = Form("wav"),
):
    """
    오디오 → 텍스트 → AI 답변 → 오디오 전체 파이프라인.

    1. Whisper STT: 오디오 → 텍스트
    2. Gemini/LLM: 텍스트 → AI 답변
    3. MeloTTS: AI 답변 → 오디오

    Response: audio/wav 바이너리
    """
    pipeline = get_voice_pipeline()
    if pipeline is None:
        raise HTTPException(503, "Voice pipeline 서비스 미준비")

    content = await file.read()
    suffix = Path(file.filename or "audio.wav").suffix or ".wav"

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp_in:
        tmp_in.write(content)
        tmp_in_path = Path(tmp_in.name)

    try:
        # STT
        transcription = pipeline.stt_only(tmp_in_path, language=language)
        transcribed_text = transcription.text

        # AI 처리 (기존 execute_ai_request 활용)
        ai_payload = {
            "intent": "GENERAL_QA",
            "prompt": transcribed_text,
            "slots": {
                "transcribed_text": transcribed_text,
                "language": transcription.language,
            },
        }
        parsed = parse_ai_request(ai_payload)
        if isinstance(parsed, JSONResponse):
            raise HTTPException(400, "AI 처리 실패")
        ai_response: AiResponse = execute_ai_request(parsed)
        ai_text = ai_response.result if hasattr(ai_response, "result") else str(ai_response)

        # TTS
        tts_result = pipeline.tts_only(
            ai_text,
            lang=transcription.language,
            speed=tts_speed,
            output_format=output_format,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Voice pipeline 오류")
        raise HTTPException(500, str(e))
    finally:
        tmp_in_path.unlink(missing_ok=True)

    media_types = {"wav": "audio/wav", "mp3": "audio/mpeg", "ogg": "audio/ogg"}
    return Response(
        content=tts_result.audio_bytes,
        media_type=media_types.get(output_format, "audio/wav"),
        headers={
            "X-Transcription": transcribed_text[:200],
            "X-Language": transcription.language,
            "X-AI-Response": ai_text[:200],
        },
    )


# ── 나머지 Spring 연동 엔드포인트들 ─────────────────────────────────────────
@router.post("/search/rag", response_model=AiResponse, responses=ERROR_RESPONSES)
def rag_search(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/community/content-search", response_model=AiResponse, responses=ERROR_RESPONSES)
def community_content_search(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/community/content-moderation", response_model=AiResponse, responses=ERROR_RESPONSES)
def community_content_moderation(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/contracts/renewal-recommendations", response_model=AiResponse, responses=ERROR_RESPONSES)
def contract_renewal(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "CONTRACT_RENEWAL_RECOMMEND")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/contracts/anomaly-detections", response_model=AiResponse, responses=ERROR_RESPONSES)
def contract_anomaly(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "CONTRACT_ANOMALY_DETECTION")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/rooms/availability-searches", response_model=AiResponse, responses=ERROR_RESPONSES)
def room_availability(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "ROOM_AVAILABILITY_SEARCH")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/common-spaces/recommendations", response_model=AiResponse, responses=ERROR_RESPONSES)
def common_space_recommend(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "COMMON_SPACE_RECOMMEND")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/payments/summary-documents", response_model=AiResponse, responses=ERROR_RESPONSES)
def payment_summary(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "PAYMENT_SUMMARY_DOCUMENT")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/payments/status-summaries", response_model=AiResponse, responses=ERROR_RESPONSES)
def payment_status(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "PAYMENT_STATUS_SUMMARY")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/payments/order-suggestions", response_model=AiResponse, responses=ERROR_RESPONSES)
def payment_order_suggest(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/operations/roomservice-stock-monitoring", response_model=AiResponse, responses=ERROR_RESPONSES)
def roomservice_stock(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "ROOMSERVICE_STOCK_MONITOR")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

@router.post("/operations/complaint-priority-classification", response_model=AiResponse, responses=ERROR_RESPONSES)
def complaint_priority(payload: Dict[str, Any] = Body(...)) -> AiResponse | JSONResponse:
    payload.setdefault("intent", "COMPLAIN_PRIORITY_CLASSIFY")
    parsed = parse_ai_request(payload)
    if isinstance(parsed, JSONResponse): return parsed
    return execute_ai_request(parsed)

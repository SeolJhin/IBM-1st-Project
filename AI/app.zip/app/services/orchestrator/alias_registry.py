# app/services/orchestrator/alias_registry.py
"""
동적 Alias 레지스트리 — 서버 시작 시 DB에서 건물명/상품명/공용공간명을 읽어와
메모리에 캐싱. 주기적으로 갱신(기본 10분).

사용처:
  1. 시스템 프롬프트에 현재 목록 주입 → LLM이 한글 입력을 정확한 DB명으로 변환
  2. _space_keywords 동적 확장 → 신규 공간명도 트리거 감지
  3. _normalize_*_in_sql 동적 확장 → 신규 상품 한글↔영문 SQL OR 확장
"""
import logging
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

# ── 갱신 주기 ─────────────────────────────────────────────────────────────────
_REFRESH_INTERVAL_SEC = 600  # 10분


# ── 캐시 저장소 ───────────────────────────────────────────────────────────────
class _AliasCache:
    def __init__(self):
        self._lock = threading.RLock()

        # 건물: [{"building_id": 1, "building_nm": "Uniplace A", "aliases": ["유니플레이스 a", ...]}]
        self.buildings: list[dict] = []

        # 상품: [{"prod_id": 1, "prod_nm": "Americano", "aliases": ["아메리카노", ...]}]
        self.products: list[dict] = []

        # 공용공간: [{"space_id": 1, "space_nm": "Fitness", "building_nm": "Uniplace A",
        #             "aliases": ["피트니스", "헬스", ...]}]
        self.spaces: list[dict] = []

        # 마지막 갱신 시각
        self.last_updated: float = 0.0
        self.initialized: bool = False

    # ── 읽기 (snapshot) ───────────────────────────────────────────────────────
    def snapshot(self) -> dict:
        with self._lock:
            return {
                "buildings": list(self.buildings),
                "products":  list(self.products),
                "spaces":    list(self.spaces),
            }

    # ── 쓰기 ──────────────────────────────────────────────────────────────────
    def update(self, buildings, products, spaces):
        with self._lock:
            self.buildings    = buildings
            self.products     = products
            self.spaces       = spaces
            self.last_updated = time.time()
            self.initialized  = True
        logger.info(
            "[AliasRegistry] 갱신 완료 — buildings=%d products=%d spaces=%d",
            len(buildings), len(products), len(spaces),
        )


_cache = _AliasCache()


# ── 한글 alias 생성 헬퍼 ──────────────────────────────────────────────────────
_SPACE_KOR_MAP = {
    # space_nm 영문 → 한글 별칭 목록
    "fitness":    ["피트니스", "헬스", "헬스장", "운동"],
    "gym":        ["헬스", "헬스장", "피트니스", "gym"],
    "lounge":     ["라운지", "휴게실", "휴게공간"],
    "meeting":    ["회의실", "미팅룸", "회의"],
    "study":      ["스터디룸", "스터디", "독서실", "공부방"],
    "coworking":  ["코워킹", "공유오피스", "근무 공간", "작업실"],
    "library":    ["도서관", "독서실"],
    "rooftop":    ["루프탑", "옥상"],
    "cafe":       ["카페", "커피숍"],
    "bbq":        ["바베큐", "bbq", "바베큐장"],
    "garden":     ["정원", "가든"],
    "laundry":    ["세탁실", "빨래방"],
    "parking":    ["주차장", "주차"],
}

def _space_aliases(space_nm: str) -> list[str]:
    """DB에 저장된 space_nm으로 한글 alias 목록 생성."""
    key = space_nm.lower().strip()
    # 정확히 매핑된 것
    if key in _SPACE_KOR_MAP:
        return _SPACE_KOR_MAP[key]
    # 부분 매핑 (예: "Fitness Center" → "fitness")
    for eng_key, kor_list in _SPACE_KOR_MAP.items():
        if eng_key in key:
            return kor_list
    return []


def _building_aliases(building_nm: str) -> list[str]:
    """
    DB 영문 building_nm → 사용자가 입력할 한글/축약 alias 목록.
    예: 'Uniplace A'    → ['유니플레이스 a', '유니플레이스a', '유니플 a', ...]
    예: 'Uniplace 청담점' → ['유니플레이스 청담점', '유니플레이스청담점', '유니플 청담점', ...]
    예: 'Uniplace 마포점' → ['유니플레이스 마포점', '유니플레이스마포점', ...]
    """
    nm_stripped = building_nm.strip()
    nm_lower    = nm_stripped.lower()
    aliases: list[str] = [nm_lower]  # 영문 소문자 기본 포함

    if nm_lower.startswith("uniplace"):
        # suffix: 원문 그대로 + 소문자 두 가지 모두 사용
        suffix_raw   = nm_stripped[len("Uniplace"):].strip()   # 원문 (예: "A", "청담점")
        suffix_lower = nm_lower[len("uniplace"):].strip()      # 소문자 (예: "a", "청담점")

        # suffix가 없으면 (그냥 "Uniplace") 브랜드명만 alias
        if not suffix_raw:
            aliases += ["유니플레이스", "유니플"]
        else:
            # 원문 suffix 기반 (대소문자 보존)
            aliases += [
                f"유니플레이스 {suffix_raw}",
                f"유니플레이스{suffix_raw}",
                f"유니플 {suffix_raw}",
                f"유니플{suffix_raw}",
            ]
            # 소문자 suffix 기반 (suffix_raw와 다를 때만 추가 — 중복 방지)
            if suffix_lower != suffix_raw:
                aliases += [
                    f"유니플레이스 {suffix_lower}",
                    f"유니플레이스{suffix_lower}",
                    f"유니플 {suffix_lower}",
                    f"유니플{suffix_lower}",
                ]
    else:
        # 비 Uniplace 건물: 소문자 원문만 (LLM이 시스템 프롬프트 목록 보고 LIKE 검색)
        pass

    # 중복 제거 후 반환
    seen: set[str] = set()
    result: list[str] = []
    for a in aliases:
        a = a.strip()
        if a and a not in seen:
            seen.add(a)
            result.append(a)
    return result


# ── DB 조회 ───────────────────────────────────────────────────────────────────
def _fetch_all() -> tuple[list, list, list]:
    """Spring을 통해 건물/상품/공용공간 목록 조회."""
    from app.services.tools.tool_executor import execute_tool

    buildings, products, spaces = [], [], []

    # 1) 건물 목록
    try:
        r = execute_tool("query_database", {
            "sql": "SELECT building_id, building_nm FROM building WHERE delete_yn='N' ORDER BY building_id",
            "description": "alias_registry: 건물 목록",
        }, None)
        for row in (r.get("data") or []):
            nm = row.get("building_nm", "")
            if nm:
                buildings.append({
                    "building_id": row.get("building_id"),
                    "building_nm": nm,
                    "aliases":     _building_aliases(nm),
                })
    except Exception as e:
        logger.debug("[AliasRegistry] 건물 조회 실패: %s", e)

    # 2) 상품 목록
    try:
        r = execute_tool("query_database", {
            "sql": "SELECT prod_id, prod_nm FROM product ORDER BY prod_id",
            "description": "alias_registry: 상품 목록",
        }, None)
        for row in (r.get("data") or []):
            nm = row.get("prod_nm", "")
            if nm:
                products.append({
                    "prod_id":  row.get("prod_id"),
                    "prod_nm":  nm,
                    "aliases":  [],   # 상품은 LLM이 직접 처리 — 목록만 제공
                })
    except Exception as e:
        logger.debug("[AliasRegistry] 상품 조회 실패: %s", e)

    # 3) 공용공간 목록 (건물명 포함)
    try:
        r = execute_tool("query_database", {
            "sql": (
                "SELECT cs.space_id, cs.space_nm, b.building_nm "
                "FROM common_space cs "
                "JOIN building b ON cs.building_id=b.building_id "
                "WHERE b.delete_yn='N' "
                "ORDER BY b.building_id, cs.space_id"
            ),
            "description": "alias_registry: 공용공간 목록",
        }, None)
        for row in (r.get("data") or []):
            nm = row.get("space_nm", "")
            if nm:
                spaces.append({
                    "space_id":    row.get("space_id"),
                    "space_nm":    nm,
                    "building_nm": row.get("building_nm", ""),
                    "aliases":     _space_aliases(nm),
                })
    except Exception as e:
        logger.debug("[AliasRegistry] 공용공간 조회 실패: %s", e)

    return buildings, products, spaces


# ── 공개 API ──────────────────────────────────────────────────────────────────
def refresh() -> None:
    """DB에서 다시 읽어와 캐시 갱신. 실패해도 예외 안 던짐."""
    try:
        buildings, products, spaces = _fetch_all()
        # 하나라도 성공적으로 조회됐으면 업데이트
        if buildings or products or spaces:
            _cache.update(buildings, products, spaces)
        else:
            logger.debug("[AliasRegistry] 조회 결과 전부 빈값 — 캐시 유지")
    except Exception as e:
        logger.debug("[AliasRegistry] refresh 실패 (캐시 유지): %s", e)


def get_buildings() -> list[dict]:
    return _cache.snapshot()["buildings"]


def get_products() -> list[dict]:
    return _cache.snapshot()["products"]


def get_spaces() -> list[dict]:
    return _cache.snapshot()["spaces"]


def is_initialized() -> bool:
    return _cache.initialized


def get_space_keywords() -> list[str]:
    """
    공용공간 트리거 키워드 목록.
    고정 기본값 + DB에서 읽어온 공간명/한글alias 합집합.
    """
    base = [
        "공용공간", "공용 공간", "공용시설", "공간 예약", "시설 예약",
        "헬스", "헬스장", "라운지", "회의실", "스터디룸", "스터디",
        "피트니스", "근무 공간", "코워킹",
    ]
    extra: set[str] = set()
    for sp in _cache.snapshot()["spaces"]:
        nm = sp.get("space_nm", "")
        if nm:
            extra.add(nm.lower())
            extra.add(nm)
        for alias in sp.get("aliases", []):
            if alias:
                extra.add(alias)
    return base + [k for k in sorted(extra) if k not in base]


def build_system_prompt_section() -> str:
    """
    시스템 프롬프트에 주입할 동적 alias 섹션 생성.
    초기화 안 됐으면 빈 문자열 반환 (하드코딩 fallback 유지).
    """
    if not _cache.initialized:
        return ""

    snap = _cache.snapshot()
    lines = ["\n[동적 데이터 목록 — DB 기준 최신 정보]\n"]

    # 건물
    if snap["buildings"]:
        lines.append("★ 건물 목록 (한글 입력 → 정확한 DB 영문명으로 변환해서 SQL 사용):")
        for b in snap["buildings"]:
            alias_str = ", ".join(b["aliases"]) if b["aliases"] else ""
            lines.append(
                f"  - building_id={b['building_id']} | DB명: \"{b['building_nm']}\" "
                f"| 한글 표현: {alias_str}"
            )
        lines.append(
            "  → 사용자가 위 한글 표현 중 하나를 말하면 해당 building_nm으로 LIKE 검색.\n"
            "  → 목록에 없는 건물명은 query_database로 building 테이블 조회 후 확인."
        )

    # 공용공간
    if snap["spaces"]:
        lines.append("\n★ 공용공간 목록 (building_id 기준으로 전체 조회됨 — 이름 직접 검색 불필요):")
        # 건물별 그룹
        by_building: dict[str, list] = {}
        for sp in snap["spaces"]:
            bnm = sp.get("building_nm", "기타")
            by_building.setdefault(bnm, []).append(sp)
        for bnm, sp_list in by_building.items():
            names = ", ".join(
                f"\"{sp['space_nm']}\""
                + (f"(={', '.join(sp['aliases'][:2])})" if sp.get("aliases") else "")
                for sp in sp_list
            )
            lines.append(f"  - {bnm}: {names}")
        lines.append(
            "  → 사용자가 위 한글 별칭을 말하면 공용공간 플로우로 진입."
        )

    # 상품
    if snap["products"]:
        prod_names = ", ".join(f"\"{p['prod_nm']}\"" for p in snap["products"][:30])
        if len(snap["products"]) > 30:
            prod_names += f" 외 {len(snap['products'])-30}개"
        lines.append(f"\n★ 룸서비스 상품 목록: {prod_names}")
        lines.append(
            "  → 상품명은 DB에 영문/한글 혼용 저장. 사용자 입력과 가장 유사한 상품을 LIKE로 검색."
        )

    return "\n".join(lines)


# ── 백그라운드 갱신 스레드 ────────────────────────────────────────────────────
def start_refresh_daemon(interval_sec: int = _REFRESH_INTERVAL_SEC) -> None:
    """주기적으로 alias 캐시를 갱신하는 백그라운드 스레드 시작."""
    def _loop():
        while True:
            time.sleep(interval_sec)
            logger.info("[AliasRegistry] 주기 갱신 시작 (interval=%ds)", interval_sec)
            refresh()

    t = threading.Thread(target=_loop, daemon=True, name="alias-registry-refresh")
    t.start()
    logger.info("[AliasRegistry] 갱신 데몬 시작 (interval=%ds)", interval_sec)